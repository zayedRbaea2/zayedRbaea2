import 'package:flutter/material.dart';
import 'database_helper.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DoctorSearchScreen(),
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
    );
  }
}

class DoctorSearchScreen extends StatefulWidget {
  @override
  _DoctorSearchScreenState createState() => _DoctorSearchScreenState();
}

class _DoctorSearchScreenState extends State<DoctorSearchScreen> {
  String? selectedSpecialty = 'All';
  String? selectedCity = 'All';
  String searchName = '';
  final dbHelper = DatabaseHelper.instance;

  final List<String> specialties = [
    'All',
    'Cardiology',
    'Dermatology',
    'Neurology',
    'Pediatrics',
    'Radiology',
  ];

  final List<String> cities = [
    'All',
    'New York',
    'Los Angeles',
    'Chicago',
    'Houston',
    'Phoenix',
  ];

  void searchDoctor() async {
    print('Searching for doctors with: specialty=$selectedSpecialty, city=$selectedCity, name=$searchName');
    final result = await dbHelper.getDoctors(selectedSpecialty, selectedCity, searchName);
    print('Search result: $result');
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SearchResultScreen(result: result),
      ),
    );
  }

  void showLoginDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        String adminName = '';
        String password = '';
        return AlertDialog(
          title: Text('Admin Login'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: InputDecoration(labelText: 'Admin Name'),
                onChanged: (value) {
                  adminName = value;
                },
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Password'),
                obscureText: true,
                onChanged: (value) {
                  password = value;
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                if (adminName == 'admin' && password == 'password') {
                  Navigator.of(context).pop();
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AddDoctorScreen()),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Invalid admin name or password')),
                  );
                }
              },
              child: Text('Login'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Doctor Search'),
        actions: [
          IconButton(
            icon: Icon(Icons.admin_panel_settings),
            onPressed: showLoginDialog,
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              decoration: InputDecoration(
                labelText: 'Search by Name',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (value) {
                setState(() {
                  searchName = value;
                });
              },
            ),
            SizedBox(height: 16.0),
            DropdownButtonFormField<String>(
              decoration: InputDecoration(
                labelText: 'Select Specialty',
                border: OutlineInputBorder(),
              ),
              value: selectedSpecialty,
              onChanged: (String? newValue) {
                setState(() {
                  selectedSpecialty = newValue;
                });
              },
              items: specialties.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            SizedBox(height: 16.0),
            DropdownButtonFormField<String>(
              decoration: InputDecoration(
                labelText: 'Select City',
                border: OutlineInputBorder(),
              ),
              value: selectedCity,
              onChanged: (String? newValue) {
                setState(() {
                  selectedCity = newValue;
                });
              },
              items: cities.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            SizedBox(height: 16.0),
            Center(
              child: ElevatedButton(
                onPressed: searchDoctor,
                child: Text('Search'),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 50, vertical: 20),
                  textStyle: TextStyle(fontSize: 18),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SearchResultScreen extends StatelessWidget {
  final List<Map<String, dynamic>> result;

  SearchResultScreen({required this.result});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Search Results'),
      ),
      body: ListView.builder(
        itemCount: result.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.symmetric(vertical: 10, horizontal: 16),
            child: ListTile(
              title: Text(result[index]['name']),
              subtitle: Text('${result[index]['specialty']} in ${result[index]['city']}'),
              leading: Icon(Icons.person),
            ),
          );
        },
      ),
    );
  }
}

class AddDoctorScreen extends StatefulWidget {
  @override
  _AddDoctorScreenState createState() => _AddDoctorScreenState();
}

class _AddDoctorScreenState extends State<AddDoctorScreen> {
  String? selectedSpecialty;
  String? selectedCity;
  final TextEditingController nameController = TextEditingController();
  final dbHelper = DatabaseHelper.instance;

  final List<String> specialties = [
    'Cardiology',
    'Dermatology',
    'Neurology',
    'Pediatrics',
    'Radiology',
  ];

  final List<String> cities = [
    'New York',
    'Los Angeles',
    'Chicago',
    'Houston',
    'Phoenix',
  ];

  void addDoctor() async {
    final name = nameController.text;
    if (selectedSpecialty != null && selectedCity != null && name.isNotEmpty) {
      Map<String, dynamic> row = {
        DatabaseHelper.instance.colSpecialty: selectedSpecialty,
        DatabaseHelper.instance.colCity: selectedCity,
        DatabaseHelper.instance.colName: name,
      };
      final result = await dbHelper.insertDoctor(row);
      await dbHelper.printAllDoctors(); // طباعة جميع الأطباء
      if (result > 0) {
        print('Doctor added successfully: $row');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Doctor added successfully')),
        );
      } else {
        print('Failed to add doctor: $row');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to add doctor')),
        );
      }
    } else {
      print('Please fill all fields');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please fill all fields')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Doctor'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                labelText: 'Doctor Name',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16.0),
            DropdownButtonFormField<String>(
              decoration: InputDecoration(
                labelText: 'Select Specialty',
                border: OutlineInputBorder(),
              ),
              value: selectedSpecialty,
              onChanged: (String? newValue) {
                setState(() {
                  selectedSpecialty = newValue;
                });
              },
              items: specialties.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            SizedBox(height: 16.0),
            DropdownButtonFormField<String>(
              decoration: InputDecoration(
                labelText: 'Select City',
                border: OutlineInputBorder(),
              ),
              value: selectedCity,
              onChanged: (String? newValue) {
                setState(() {
                  selectedCity = newValue;
                });
              },
              items: cities.map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            SizedBox(height: 16.0),
            Center(
              child: ElevatedButton(
                onPressed: addDoctor,
                child: Text('Add Doctor'),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 50, vertical: 20),
                  textStyle: TextStyle(fontSize: 18),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
