import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._instance();
  static Database? _db;

  DatabaseHelper._instance();

  String doctorTable = 'doctor_table';
  String colId = 'id';
  String colSpecialty = 'specialty';
  String colCity = 'city';
  String colName = 'name';

  Future<Database?> get db async {
    if (_db == null) {
      _db = await _initDb();
    }
    return _db;
  }

  Future<Database> _initDb() async {
    String path = join(await getDatabasesPath(), 'doctors.db');
    final doctorsDb = await openDatabase(path, version: 10, onCreate: _createDb);
    return doctorsDb;
  }

  void _createDb(Database db, int version) async {
    await db.execute(
      'CREATE TABLE $doctorTable($colId INTEGER PRIMARY KEY AUTOINCREMENT, $colSpecialty TEXT, $colCity TEXT, $colName TEXT)',
    );
    await _insertInitialData(db);
  }

  Future<void> _insertInitialData(Database db) async {
    await db.insert(doctorTable, {'specialty': 'Cardiology', 'city': 'New York', 'name': 'Dr. Smith'});
    await db.insert(doctorTable, {'specialty': 'Dermatology', 'city': 'Los Angeles', 'name': 'Dr. Johnson'});
    await db.insert(doctorTable, {'specialty': 'Neurology', 'city': 'Chicago', 'name': 'Dr. Williams'});
    await db.insert(doctorTable, {'specialty': 'Pediatrics', 'city': 'Houston', 'name': 'Dr. Brown'});
    await db.insert(doctorTable, {'specialty': 'Radiology', 'city': 'Phoenix', 'name': 'Dr. Davis'});
  }

  Future<int> insertDoctor(Map<String, dynamic> row) async {
    Database? db = await this.db;
    final int result = await db!.insert(doctorTable, row);
    return result;
  }

  Future<List<Map<String, dynamic>>> getDoctors(String? specialty, String? city, String name) async {
    Database? db = await this.db;
    String whereString = '';
    List<dynamic> whereArguments = [];

    if (specialty != null && specialty != 'All') {
      whereString += '$colSpecialty = ?';
      whereArguments.add(specialty);
    }

    if (city != null && city != 'All') {
      if (whereString.isNotEmpty) whereString += ' AND ';
      whereString += '$colCity = ?';
      whereArguments.add(city);
    }

    if (name.isNotEmpty) {
      if (whereString.isNotEmpty) whereString += ' AND ';
      whereString += '$colName LIKE ?';
      whereArguments.add('%$name%');
    }

    final List<Map<String, dynamic>> result = await db!.query(
      doctorTable,
      where: whereString.isEmpty ? null : whereString,
      whereArgs: whereArguments.isEmpty ? null : whereArguments,
    );
    return result;
  }

  Future<void> printAllDoctors() async {
    Database? db = await this.db;
    final List<Map<String, dynamic>> result = await db!.query(doctorTable);
    print('All doctors in the database: $result');
  }
}
